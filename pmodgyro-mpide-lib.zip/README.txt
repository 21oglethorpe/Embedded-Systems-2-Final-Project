To install:

1. Start MPIDE
2. Look under File->Preferences and take note of your Sketchbook Location
3. Shutdown MPIDE
4. Under your Sketchbook directory, create a subdirectory called "libraries"; this directory may already exist.
5. Place the unzipped library folder (example:  "OLED", "GYRO", etc) into this "libraries" directory.
6. Restart MPIDE
7. You should see the new library under Sketch->Import Library, under Contributed
8. You should also see the chipKIT library examples directory under File->Examples.
